const colors = require('colors');

console.log('🍞Bem vindo a padaria do João!'.rainbow);
console.log('Pães frescos todos os dias!'.green);
console.log('Horario: 6h ás 18h'.blue);