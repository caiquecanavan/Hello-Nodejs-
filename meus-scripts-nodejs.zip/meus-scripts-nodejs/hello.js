console.log("Olá, teste");
console.log("Meu nome é Caique");
console.log('Versão do Node.js:', process.version); 
console.log('Plataforma:', process.platform);

function DadosPessoais(nome, idade) {
  console.log(`Meu nome é ${nome}, e tenho ${idade} anos.`)
};

DadosPessoais("Vinicius", 17);
DadosPessoais("Felipe", 17);
DadosPessoais("Castro", 18);
DadosPessoais("Risada", 17);
DadosPessoais("Caique", 17);

for (let i = 0; i < 10; i++) {
    console.log(i)
};